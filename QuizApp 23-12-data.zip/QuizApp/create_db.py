import sqlite3
import bcrypt  # For password hashing

# Connect to the database
def get_db_connection():
    conn = sqlite3.connect('database.db')
    conn.row_factory = sqlite3.Row  # Enables row access by column name
    return conn

# Function to create tables
def create_tables():
    conn = get_db_connection()
    cursor = conn.cursor()

    try:
        # Create users table
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS users (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL,
                email TEXT NOT NULL UNIQUE,
                password TEXT NOT NULL
            )
        ''')

        # Create Standard 1 questions table
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS std1_questions (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                question TEXT NOT NULL,
                option1 TEXT NOT NULL,
                option2 TEXT NOT NULL,
                option3 TEXT NOT NULL,
                option4 TEXT NOT NULL,
                correct_option TEXT NOT NULL
            )
        ''')

        # Create user answers table
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS user_answers (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER NOT NULL,
                question_id INTEGER NOT NULL,
                selected_option TEXT NOT NULL,
                is_correct BOOLEAN NOT NULL,
                FOREIGN KEY (user_id) REFERENCES users (id),
                FOREIGN KEY (question_id) REFERENCES std1_questions (id)
            )
        ''')

        # Create admin table
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS admin (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                username TEXT NOT NULL UNIQUE,
                password TEXT NOT NULL
            )
        ''')

        conn.commit()
        print("Tables created successfully!")

    except sqlite3.Error as e:
        print("Error creating tables:", e)

    finally:
        conn.close()

# Function to insert sample questions
def insert_sample_questions():
    conn = get_db_connection()
    cursor = conn.cursor()

    sample_questions = [
        ('What is 2 + 2?', '3', '4', '5', '6', 'option2'),
        ('What is the capital of France?', 'London', 'Berlin', 'Paris', 'Madrid', 'option3'),
        ('What color is the sky?', 'Blue', 'Green', 'Red', 'Yellow', 'option1')
    ]

    try:
        for question in sample_questions:
            cursor.execute('''
                INSERT INTO std1_questions (question, option1, option2, option3, option4, correct_option)
                SELECT ?, ?, ?, ?, ?, ?
                WHERE NOT EXISTS (
                    SELECT 1 FROM std1_questions WHERE question = ?
                )
            ''', (*question, question[0]))

        conn.commit()
        print("Sample questions added successfully!")

    except sqlite3.Error as e:
        print("Error inserting questions:", e)

    finally:
        conn.close()

# Function to view registered users
def view_users():
    conn = get_db_connection()
    cursor = conn.cursor()

    try:
        cursor.execute('SELECT id, name, email FROM users')
        rows = cursor.fetchall()

        if rows:
            print("\nRegistered Users:")
            print("====================")
            for row in rows:
                print(f"ID: {row['id']}, Name: {row['name']}, Email: {row['email']}")
        else:
            print("No users found in the database.")

    except sqlite3.Error as e:
        print("Database error:", e)

    finally:
        conn.close()

# Function to insert a default admin user
def insert_admin_user():
    conn = get_db_connection()
    cursor = conn.cursor()

    try:
        # Hash the default admin password
        admin_password = bcrypt.hashpw('admin123'.encode('utf-8'), bcrypt.gensalt())

        # Insert a default admin user
        cursor.execute('''
            INSERT OR IGNORE INTO admin (username, password)
            VALUES ('admin', ?)
        ''', (admin_password.decode('utf-8'),))

        conn.commit()
        print("Admin user added successfully!")

    except sqlite3.Error as e:
        print("Error adding admin user:", e)

    finally:
        conn.close()

# Main menu for database operations
def main():
    print("\nDatabase Management Menu")
    print("========================")
    print("1. Create tables")
    print("2. Insert sample questions")
    print("3. View registered users")
    print("4. Insert default admin user")
    print("5. Exit")

    while True:
        choice = input("\nEnter your choice: ").strip()

        if choice == '1':
            create_tables()
        elif choice == '2':
            insert_sample_questions()
        elif choice == '3':
            view_users()
        elif choice == '4':
            insert_admin_user()
        elif choice == '5':
            print("Exiting program. Goodbye!")
            break
        else:
            print("Invalid choice. Please try again.")

if __name__ == '__main__':
    main()
