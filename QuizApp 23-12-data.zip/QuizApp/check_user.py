import sqlite3

def view_users():
    # Connect to the database
    conn = sqlite3.connect('database.db')
    cursor = conn.cursor()

    # Execute query to select all users
    cursor.execute('SELECT * FROM users')
    rows = cursor.fetchall()

    print("Registered Users:")
    print("====================")
    for row in rows:
        print(f"ID: {row[0]}, Name: {row[1]}, Email: {row[2]}, Password: {row[3]}")

    # Close the connection
    conn.close()

# Call the function to view users
view_users()
