from flask import Flask, render_template, request, redirect, url_for, flash, session
import sqlite3
import hashlib

app = Flask(__name__)
app.secret_key = 'your_secret_key'  # Required for flash messages and session management

# Mock database for questions
def get_questions_from_db():
    return [
        {"id": 1, "question": "What is 2 + 2?", "option1": "3", "option2": "4", "option3": "5", "option4": "6"},
        {"id": 2, "question": "What is the capital of France?", "option1": "London", "option2": "Berlin", "option3": "Paris", "option4": "Madrid"},
        {"id": 3, "question": "Which color is the sky?", "option1": "Green", "option2": "Yellow", "option3": "Blue", "option4": "Red"}
    ]

# Function to query the database
def query_db(query, args=(), one=False):
    connection = sqlite3.connect('your_database.db')
    connection.row_factory = sqlite3.Row  # Return rows as dictionaries
    cursor = connection.cursor()

    cursor.execute(query, args)
    result = cursor.fetchone() if one else cursor.fetchall()

    connection.commit()
    connection.close()

    return result

def get_db_connection():
    conn = sqlite3.connect('database.db')  # Connect to your database
    conn.row_factory = sqlite3.Row  # Enable column access by name
    return conn

@app.route('/')
def index():
    return render_template('index.html')

#login route
@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        
        # Hash password before checking
        hashed_password = hashlib.sha256(password.encode()).hexdigest()

        conn = get_db_connection()
        user = conn.execute('SELECT * FROM users WHERE username = ? AND password = ?', (username, hashed_password)).fetchone()
        conn.close()

        if user:
            session['user_id'] = user['id']  # Store user session
            flash('Login successful!', 'success')
            return redirect(url_for('index'))  # Redirect to index page
        else:
            flash('Invalid credentials. Please try again or register.', 'danger')
            return redirect(url_for('login'))  # Stay on the login page if login failed

    return render_template('login.html')

#register route
@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']

        # Hash password before saving
        hashed_password = hashlib.sha256(password.encode()).hexdigest()

        conn = get_db_connection()
        # Check if user already exists
        existing_user = conn.execute('SELECT * FROM users WHERE username = ?', (username,)).fetchone()
        
        if existing_user:
            flash('Username already exists. Please choose another one.', 'warning')
            return redirect(url_for('register'))
        
        conn.execute('INSERT INTO users (username, password) VALUES (?, ?)', (username, hashed_password))
        conn.commit()
        conn.close()

        flash('Registration successful. Please log in.', 'success')
        return redirect(url_for('login'))

    return render_template('register.html')

#home route
@app.route('/home')
def home():
    if 'user_id' not in session:
        flash('You must log in to access the home page.', 'warning')
        return redirect(url_for('login'))

    return render_template('index.html')


# Route for Standard 1 Quiz Page
@app.route('/standard/<int:std>', methods=['GET', 'POST'])
def standard(std):
    if 'user_id' not in session:
        flash('Please login first to take the quiz.', 'error')
        return redirect(url_for('login'))

    # Define questions based on standard
    questions_by_standard = {
        1: [
            {'id': 1, 'question': "What is 2 + 2?", 'option1': "3", 'option2': "4", 'option3': "5", 'option4': "6"},
            {'id': 2, 'question': "What is the capital of France?", 'option1': "Berlin", 'option2': "Paris", 'option3': "Madrid", 'option4': "Rome"},
            {'id': 3, 'question': "Which color is the sky?", 'option1': "Green", 'option2': "Yellow", 'option3': "Blue", 'option4': "Red"}
        ],
        # Add more standards here if needed
    }

    questions = questions_by_standard.get(std)
    if not questions:
        flash("Quiz for this standard is not available.", "warning")
        return redirect(url_for('index'))

    if request.method == 'POST':
        selected_answers = request.form
        results = []
        for question in questions:
            user_answer = selected_answers.get(str(question['id']))
            is_correct = (user_answer == "option2")  # Correct answers predefined
            results.append({
                'question': question['question'],
                'selected': question.get(user_answer, ''),
                'correct': question['option2'],
                'is_correct': is_correct
            })

        return render_template('score.html', score=sum([1 if res['is_correct'] else 0 for res in results]), results=results)

    return render_template('std1.html', questions=questions)


@app.route('/admin/std1')
def admin_std1():
    questions = get_questions_from_db()  # Replace with database fetching logic
    return render_template('admin_std1.html', questions=questions)

@app.route('/std1')
def std1():
    questions = get_questions_from_db()  # Replace with database fetching logic
    return render_template('std1.html', questions=questions)


#admin std1 route
@app.route('/admin/std1', methods=['GET', 'POST'])
def std1_questions():
    questions = [
        {
            "id": 1,
            "question": "What is 2 + 2?",
            "options": {"option1": "3", "option2": "4", "option3": "5", "option4": "6"}
        },
        {
            "id": 2,
            "question": "What is the capital of France?",
            "options": {"option1": "London", "option2": "Berlin", "option3": "Paris", "option4": "Madrid"}
        },
        {
            "id": 3,
            "question": "Name the largest planet in our solar system.",
            "options": {"option1": "Mars", "option2": "Earth", "option3": "Jupiter", "option4": "Saturn"}
        }
    ]
    
    if request.method == 'POST':
        # Handle submitted answers here
        submitted_answers = request.form
        print(submitted_answers)  # Debug: print submitted answers to the console
        return "Answers submitted successfully!"

    return render_template('std1.html', questions=questions)

#admin std1 Routes for Edit and Delete
@app.route('/admin/edit_question/<int:question_id>', methods=['GET', 'POST'])
def edit_question(question_id):
    if request.method == 'POST':
        # Handle editing logic here
        updated_data = request.form
        # Save the updated question
        return f"Question {question_id} updated successfully!"
    # Fetch question data for the given ID
    question = {"id": question_id, "question": "Sample question", "options": {"option1": "Option 1", "option2": "Option 2"}}
    return render_template('edit_question.html', question=question)

@app.route('/admin/delete_question/<int:question_id>', methods=['DELETE'])
def delete_question(question_id):
    # Perform delete operation here
    return {"status": "success", "message": f"Question {question_id} deleted successfully"}



# Route for course_a Quiz Page
@app.route('/course_a', methods=['GET', 'POST'])
def course_a():
    if not session.get('user_id'):
        flash("Please login first to take the quiz.", "error")
        return redirect(url_for('login'))  # Redirect to login page if not logged in

    # Mock questions for Course A
    questions = [
        {'id': 1, 'question': 'What is the capital of France?', 'option1': 'Paris', 'option2': 'London', 'option3': 'Berlin', 'option4': 'Madrid', 'correct': 'option1'},
        {'id': 2, 'question': 'Which planet is known as the Red Planet?', 'option1': 'Earth', 'option2': 'Mars', 'option3': 'Jupiter', 'option4': 'Saturn', 'correct': 'option2'},
        {'id': 3, 'question': 'What is the largest ocean on Earth?', 'option1': 'Atlantic', 'option2': 'Indian', 'option3': 'Arctic', 'option4': 'Pacific', 'correct': 'option4'}
    ]

    if request.method == 'POST':
        score = 0
        results = []

        for question in questions:
            selected = request.form.get(str(question['id']))
            is_correct = selected == question['correct']
            if is_correct:
                score += 1

            results.append({
                'question': question['question'],
                'selected': question.get(selected, 'No answer'),
                'correct': question.get(question['correct']),
                'is_correct': is_correct
            })

        return render_template('score_course_a.html', score=score, results=results)

    return render_template('course_a.html', questions=questions)


#courseroute
@app.route('/course/<course>') 
def course(course):
    # Check if the user is logged in
    if not session.get('user_id'):
        flash("Please login first to access the course.", "error")
        return redirect(url_for('login'))  # Redirect to login page

    # Logic for showing the quiz for the selected course
    return f"Quiz for Course {course}"

#frontend logout route
@app.route('/logout')
def logout():
    # Clear the session
    session.pop('user_id', None)
    flash('You have been logged out.', 'info')
    return redirect(url_for('login'))  # Redirect to login page after logout

# Admin Login Route
@app.route('/admin_login', methods=['GET', 'POST'])
def admin_login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        
        # Check admin credentials
        if username == "ankit" and password == "ankit123":
            session['admin_id'] = username  # Store admin session
            flash('Welcome, Admin!', 'success')
            return redirect(url_for('admin_panel'))  # Redirect to admin panel
        else:
            flash('Invalid credentials. Please try again.', 'error')
    
    return render_template('admin_login.html')


# Admin Panel Route
@app.route('/admin_panel')
def admin_panel():
    if 'admin_id' not in session:
        flash('Please log in as admin to access this page.', 'error')
        return redirect(url_for('admin_login'))
    
    return render_template('admin.html')


# Admin Logout Route
@app.route('/admin_logout')
def admin_logout():
    session.pop('admin_id', None)  # Clear admin session
    flash('Logged out successfully.', 'success')  # Feedback
    return redirect(url_for('admin_login'))  # Redirect to admin login


if __name__ == '__main__':
    app.run(debug=True)
